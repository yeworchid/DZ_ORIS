﻿using System.Text.Json;
using MiniHttpServer.Shared;
using MiniHttpServer.Services;

var server = new HttpServer();
await server.StartAsync();