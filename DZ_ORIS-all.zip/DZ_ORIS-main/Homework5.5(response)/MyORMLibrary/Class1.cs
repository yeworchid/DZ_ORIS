﻿namespace MyORMLibrary;

public class Class1
{

}
